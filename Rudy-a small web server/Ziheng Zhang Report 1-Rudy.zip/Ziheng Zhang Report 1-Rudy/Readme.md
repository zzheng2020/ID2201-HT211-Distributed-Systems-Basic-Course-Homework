# README: Rudy -  a small web server

This file has 12 items.

`http.erl`: implement the http parsing.

`rudy.erl`: implement the Rudy server.

`test.erl`: test performance of Rudy server.

`rudyPool.erl`: increase Rudy server throughout.

`practice.erl`: test  `gen_tcp:...` function.

`Ziheng Zhang Report ...`: report of Assignment 1.

